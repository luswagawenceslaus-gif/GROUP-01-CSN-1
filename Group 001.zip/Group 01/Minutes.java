import java.util.Scanner;

public class Minutes{
    public static void main(String[] args) {
        
        Scanner agent = new Scanner(System.in);

        System.out.println("Enter the number of minutes: ");
        int minutes = agent.nextInt();

        int years = minutes / 525600;
        int calReminder = minutes % 525600;
        int days = calReminder / 1440;

        System.out.println(minutes + " minutes is approximately to " + years + " years and " + days + " days." );
        
    }
}
        
    
    


