import java.util.Scanner;

public class Subtotal{
    public static void main(String[] args){

        Scanner user = new Scanner(System.in);
        System.out.println("Enter subtotal");
        float sub = user . nextFloat();
        System.out.println("Enter gratuity");
        float grat = user .nextFloat();

        float gratuity = sub * (grat/100);
        float total = sub + gratuity;
        System.out.println("Gratuity is $" + gratuity + "and subtotal is $" + total);


    }
}