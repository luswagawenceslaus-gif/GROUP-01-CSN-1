public class Iteration{
    public static void main (String[] arg){
        for (int z= 1; z <= 5; z++) {
             System.out.println("welcome to java");
             }
             }
}