import java.util.Scanner;

public class celcius{
    public static void main(String[] args) {
        Scanner input =new Scanner(System.in);

        System.out.println("Enter degrees in celicius: " );
        double cel = input.nextDouble();

        System.out.println("u entered: " + cel);
        double fah = (9/5) * cel + 32;
        
        System.out.println(cel + " Celsius is " + fah + "fahrenheight");

    }
}
        
    
    

