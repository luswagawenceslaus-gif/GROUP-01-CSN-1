import java.util.Scanner;

public class Volume{
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the radius: ");
        double rad = input.nextDouble(); 
        System.out.print("Enter the Length: ");
        double leng = input.nextDouble(); 

        double area = rad * rad * 3.14;
        double volume = area * leng;

        System.out.println("The area is: " + area + " and the volume is: " + volume);


    }
}
        
    
    


