public class Welcome{
    public static void main(String[] args) {
        System.out.println("Welcome to java");
        System.out.println("Welcome to computer science");
        System.out.println("program is fun");

    }
} 