
import java.util.Scanner;

public class Task05 {

    public static void main(String[] args) {
        Scanner details = new Scanner(System.in);

        System.out.print("Enter your Name: ");
        String name = details.nextLine();
        System.out.print("Enter your Registration Number: ");
        String regNo = details.nextLine();
        System.out.print("Enter your Marks: ");
        int marks = details.nextInt();

        System.out.println("Name: " + name + " | Registration Number: " + regNo + " | Marks: " + marks);
    }
    
}
