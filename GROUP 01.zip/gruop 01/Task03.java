import java.util.Scanner;

public class Task03 {

    public static void main(String[] args) {

        Scanner text = new Scanner(System.in);
        System.out.println("Enter your first name: ");
        String name = text.nextLine();

        System.out.println( "In uppercase: " + name.toUpperCase()); //prints in Upper case
        System.out.println("In Lowercase: " + name.toLowerCase()); //Prints in Lower case
        System.out.println("Character length: " + name.length()); // prints String length

        char search = 'a';
        int count = 0;

        for (int i = 0; i<= name.length() - 1; i++){

            if (name.charAt(i) == search){

                count++;
            }
        }
        System.out.println("Character a occured " + count + " times.");
        //System.out.println(name.replace('', '_'));
        
    }
    
}
