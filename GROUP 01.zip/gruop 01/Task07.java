
import java.time.LocalDate;
import java.time.LocalTime;

public class Task07 {

    public static void main(String[] args) {
        
        LocalDate date = LocalDate.now(); //sets the current date
        LocalTime time = LocalTime.now(); //sets the current time

        System.out.println("The current date is: " + date); //prints current date
        System.out.println("The current time is: " + time); // prints current time
        System.out.println("The current year is: " + LocalDate.now().getYear()); // prints current year
    }
    
}
