public class Task01 {
   public static void main(String[] args){

    String name = "Princess Mlambo"; // This shows my full name
    System.out.println(name); // This prints my full name
    System.out.println(name.length()); // This shows string length


   }
}
