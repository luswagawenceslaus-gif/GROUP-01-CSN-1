public class Task02 {

    public static void main(String[] args) {

        String text = "Computer Science";
        System.out.println(text.charAt(0)); // Prints the 1st character
        int length = text.length(); //calculate string length
        System.out.println(text.charAt(length-1)); /// prints the last character
        System.out.println(text.substring(9)); //Extract the word Science
    }
    
}