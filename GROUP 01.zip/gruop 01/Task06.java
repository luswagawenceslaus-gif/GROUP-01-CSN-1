import java.util.Scanner;

public class Task06 {

    public static void main(String[] args) {
        Scanner number = new Scanner(System.in);

        System.out.print("Enter a number: ");
        double num = number.nextDouble();

        double sqr = Math.sqrt(num); // calculates the square root
        double pow = Math.pow(num,2); // calculates the power of 2
        double pi = Math.PI; // stores the value of pi

        System.out.println("The square root of " + num + " is " + sqr);
        System.out.println(num + " Power 2 is " + pow);
        System.out.println("The value of Pi is " + pi);
    }
    
}
