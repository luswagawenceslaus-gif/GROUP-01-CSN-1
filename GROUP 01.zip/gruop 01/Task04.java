
import java.util.Scanner;

public class Task04 {

    public static void main(String[] args) {
        Scanner userInputs = new Scanner(System.in);

        System.out.println("Enter two strings");
        System.out.print("String 1: ");
        String str1 = userInputs.nextLine();
        System.out.print("String 2: ");
        String str2 = userInputs.nextLine();

        if(str1.equals(str2)){

            System.out.println("The strings are equal");
        }

        else {

            System.out.println("The strings are not equal");
        }

        System.out.println("String 1 length: " + str1.length());
        System.out.println("String 2 length: " + str2.length());

    }
    
}
